from typing import TypedDict


class RemittanceState(TypedDict, total=False):
    document: str
    payer: str
    amount: float
    invoices: list
    matches: list

    confidence: float
    next_agent: str

    requires_hitl: bool
    approved: bool

    error: str
    final_result: str
