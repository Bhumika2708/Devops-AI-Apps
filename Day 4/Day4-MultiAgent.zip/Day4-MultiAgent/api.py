from fastapi import FastAPI
from pydantic import BaseModel

from graph import graph


app = FastAPI()


class Request(BaseModel):
    document: str


@app.get("/")
def health():
    return {
        "status": "running",
        "application": "Day4 Multi-Agent AI"
    }


@app.post("/process")
def process(request: Request):

    state = {
        "document": request.document,
        "approved": True
    }

    result = graph.invoke(state)

    return {
        "payer": result.get("payer"),
        "amount": result.get("amount"),
        "confidence": result.get("confidence"),
        "matches": result.get("matches"),
        "result": result.get("final_result")
    }
