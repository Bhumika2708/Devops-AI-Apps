import os
from dotenv import load_dotenv

from langchain.agents import create_agent
from langchain_openai import AzureChatOpenAI
from langchain.tools import tool

load_dotenv()


model = AzureChatOpenAI(
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
    azure_deployment=os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"],
    api_version=os.environ["AZURE_OPENAI_API_VERSION"],
    temperature=1
)


@tool
def lookup_invoice(invoice_id: str) -> str:
    """Look up an invoice amount."""

    invoices = {
        "INV-1001": 5000,
        "INV-1002": 7500,
        "INV-1003": 3250
    }

    amount = invoices.get(invoice_id)

    if amount is None:
        return "Invoice not found."

    return f"{invoice_id}: ${amount:.2f}"


agent = create_agent(
    model,
    tools=[lookup_invoice],
    system_prompt=(
        "You are a remittance processing assistant. "
        "Use the invoice tool when invoice information is required."
    )
)


result = agent.invoke({
    "messages": [
        {
            "role": "user",
            "content": "What is the amount of invoice INV-1001?"
        }
    ]
})

print(result["messages"][-1].content)
