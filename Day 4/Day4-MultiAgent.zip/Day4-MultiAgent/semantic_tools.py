from semantic_kernel.functions import kernel_function


class RemittancePlugin:

    @kernel_function(
        name="lookup_invoice",
        description="Look up an invoice amount using its invoice ID."
    )
    def lookup_invoice(self, invoice_id: str) -> str:

        invoices = {
            "INV-1001": 5000,
            "INV-1002": 7500,
            "INV-1003": 3250
        }

        amount = invoices.get(invoice_id)

        if amount is None:
            return f"Invoice {invoice_id} was not found."

        return f"Invoice {invoice_id}: ${amount:.2f}"
Now update semantic_kernel_app.py:
from semantic_tools import RemittancePlugin

kernel.add_plugin(
    RemittancePlugin(),
    plugin_name="Remittance"
)

result = await kernel.invoke(
    kernel.plugins["Remittance"]["lookup_invoice"],
    invoice_id="INV-1001"
)

print(result)
