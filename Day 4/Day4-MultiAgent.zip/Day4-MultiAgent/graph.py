from langgraph.graph import StateGraph, START, END

from state import RemittanceState
from agents import (
    supervisor_agent,
    ingestion_agent,
    matching_agent,
    hitl_review,
    final_agent
)


def route_after_matching(state):

    confidence = state.get("confidence", 0)

    if confidence >= 0.85:
        return "final"

    return "hitl"


builder = StateGraph(RemittanceState)

builder.add_node(
    "supervisor",
    supervisor_agent
)

builder.add_node(
    "ingestion",
    ingestion_agent
)

builder.add_node(
    "matching",
    matching_agent
)

builder.add_node(
    "hitl",
    hitl_review
)

builder.add_node(
    "final",
    final_agent
)


builder.add_edge(
    START,
    "supervisor"
)

builder.add_edge(
    "supervisor",
    "ingestion"
)

builder.add_edge(
    "ingestion",
    "matching"
)

builder.add_conditional_edges(
    "matching",
    route_after_matching,
    {
        "final": "final",
        "hitl": "hitl"
    }
)

builder.add_edge(
    "hitl",
    "final"
)

builder.add_edge(
    "final",
    END
)


graph = builder.compile()
