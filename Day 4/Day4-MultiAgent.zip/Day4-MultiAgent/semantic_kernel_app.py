import os
import asyncio
from dotenv import load_dotenv

from semantic_kernel import Kernel
from semantic_kernel.connectors.ai.open_ai import AzureChatCompletion

load_dotenv()

kernel = Kernel()

chat_service = AzureChatCompletion(
    deployment_name=os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"],
    endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
)

kernel.add_service(chat_service)


async def main():
    result = await kernel.invoke_prompt(
        "Explain what an AI agent is in simple terms."
    )

    print("\nSemantic Kernel Response:\n")
    print(result)


if __name__ == "__main__":
    asyncio.run(main())
