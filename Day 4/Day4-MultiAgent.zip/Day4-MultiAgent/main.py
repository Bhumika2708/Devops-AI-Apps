from graph import graph


document = """
Remittance Advice

Payer: Contoso Ltd

Payment Amount: $15,750

Invoices:
INV-1001
INV-1002
INV-1003
"""


initial_state = {
    "document": document,
    "requires_hitl": False,
    "approved": True
}


result = graph.invoke(initial_state)


print("\n===================================")
print("MULTI-AGENT PROCESSING COMPLETE")
print("===================================")

print("\nPayer:")
print(result.get("payer"))

print("\nAmount:")
print(result.get("amount"))

print("\nConfidence:")
print(result.get("confidence"))

print("\nMatches:")
print(result.get("matches"))

print("\nFinal Result:")
print(result.get("final_result"))
