def supervisor_agent(state):

    if not state.get("payer"):
        return {"next_agent": "ingestion"}

    if not state.get("matches"):
        return {"next_agent": "matching"}

    return {"next_agent": "complete"}


def ingestion_agent(state):

    document = state["document"]

    return {
        "payer": "Contoso Ltd",
        "amount": 15750.00,
        "invoices": [
            "INV-1001",
            "INV-1002",
            "INV-1003"
        ]
    }


def matching_agent(state):

    matches = [
        {
            "invoice": "INV-1001",
            "status": "matched",
            "confidence": 0.98
        },
        {
            "invoice": "INV-1002",
            "status": "matched",
            "confidence": 0.96
        },
        {
            "invoice": "INV-1003",
            "status": "matched",
            "confidence": 0.99
        }
    ]

    confidence = 0.60
    

    return {
        "matches": matches,
        "confidence": confidence
    }


def hitl_review(state):

    print("\nHuman review required.")

    decision = input(
        "Approve transaction? (approve/reject): "
    )

    return {
        "approved": decision.lower() == "approve"
    }


def final_agent(state):

    if state.get("approved") is False:
        result = "Transaction rejected by human reviewer."

    else:
        result = (
            f"Payer: {state.get('payer')}\n"
            f"Amount: ${state.get('amount', 0):.2f}\n"
            f"Confidence: {state.get('confidence', 0):.2f}"
        )

    return {
        "final_result": result
    }
